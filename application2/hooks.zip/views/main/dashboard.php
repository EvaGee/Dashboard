<!-- Main content -->
<div class="content-wrapper">
	<div class="panel panel-white">
		<div class="panel-heading">
			<h6 class="panel-title">Manage Event</h6>			
		</div> 
		<div style="margin-top: 1%; margin-left: 1%">
			<a href="<?php echo base_url()?>index.php/my-event"><button>VIEW EVENTS</button></a>
		</div> 

		<?php
		if ($this->session->userdata('role') == 1) {			
		?>
		<div style="margin-top: 1%; margin-left: 1%">
			<a href="<?echo base_url(); ?>index.php/pending-event"><button>PENDING EVENTS</button></a>
		</div> 

	<?php } ?>

	</div>

</div>
